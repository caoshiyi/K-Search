# 第三轮设计文档：MM1 K 大块转置加载（`LoadNzL1ToZnL0BWithTranspose`）

> **本轮优化点：把 MM1 的 K（B 矩阵）加载从「每块 128 行裸 LoadData2D」升级为「每块 256 行大块加载 + 转置感知的 L0B 子块抽取」。**
> **基线 = 第二轮 977us 的「双向两级分块 + 多缓冲 PRELAUNCH 软流水」版（commit 0dc4b54，分支 exp/blind-design-impl）。**
> 收益与风险一律相对 **977us** 评估（见 lessons_round2 §5.2：基线锚定第二轮，不锚定 1590us/2391us）。

---

## 0. 范围声明（先划清「改什么 / 不改什么」）

本轮**只抽取一个增量优化点**：MM1（S = Q@Kᵀ）里 K 矩阵从 L1 加载到 L0B 的路径。

具体地，把第二轮 MM1 的「外层每 128 行（BLOCK_N）K 微块 GM→L1，K→L0B 用裸 `LoadData2D` 整块连续拷贝」，改为「外层每 256 行（`nL1Size`）K 大块 GM→L1，再在内层用 `LoadNzL1ToZnL0BWithTranspose` 从大块里按 128 行 n 子块抽取到 L0B」。

**为什么这两件事是同一个变量（不可拆）：** `LoadNzL1ToZnL0BWithTranspose` 在 `colC0Stride == n` 时**退化为与基线裸 `LoadData2D` 逐字节等价的单条指令**（见 §4 helper 的 if 分支）。它只有在「L1 里的 K 块比 L0B 的 n 子块更宽（colC0Stride=256 ≠ n=128）」时才走 C0 分块循环、才与基线不同。所以「引入转置 helper」与「把 K 块放大到 256 行」是一件事的两面，必须一起做，否则 helper 等于没改。本轮把这二者作为**单一逻辑变量**抽取。

**保持不变（第一/二轮已落地、已验证的结构前提，禁止重构）：**
- 第二轮的 PRELAUNCH=2 软流水顶层调度（`flash_attention_kernel.h` 的 `for t < s2OuterBlocks+PRELAUNCH` 错位发射循环）——**完全不动**。
- 第二轮的全部跨核 CrossCore 同步契约（SIG_S/P/O_READY、WorkspaceQueue 的 ProducerAcquire/ReleaseFix/ConsumerAcquire）——**完全不动**（见 §5）。
- 第二轮的多缓冲 TQue 结构（kpQueL1_ 深度3、vQueL1_ 深度2、queL0A/B 深度2、queL0C_ 深度2）与 EnQue/DeQue/FreeTensor 自动跨流水 flag——**完全不动**。
- **MM1 的 Q（A 矩阵）→ L0A 加载路径**：保持第二轮的「逐 C0 行 `LoadData2D` 循环」**逐字节不变**（见 §3 伪代码 Q 段）。本轮**不**引入 main 的 `LoadNzL1ToZzL0A` 单指令 Q 加载——那是另一个独立增量，留给后续轮次，以保持本轮单变量隔离纯净。
- **MM2（O = P@V）整段**：加载方式、KL1 切分、循环结构**完全保持第二轮**。本轮不碰 MM2。
- LoadQ、Vec1/Vec2、tiling 公式（mBaseSize/s2BaseSize/PRELAUNCH/RING_SLOTS/ws 尺寸）——**完全不动**。

**本轮要改的（且仅此）：**
1. `matmul_tile.h`：**新增**一个自补 helper `LoadNzL1ToZnL0BWithTranspose`（基线 matmul_tile.h 没有，见 §4，须逐字节按本文档实现）。
2. `flash_attention_cube.h` 的 `ComputeMM1`：K 外层循环步长 128→`nL1Size`（自适应 256/128），新增 n 方向 L0B 子块内层循环，K→L0B 改调 `LoadNzL1ToZnL0BWithTranspose`。
3. `flash_attention_cube.h` 的 `InitBuffers`：`kpQueL1_` 单槽尺寸按 MM1 K 大块重算（见 §6）。

---

## 1. 根因与差距的诚实拆解（吸取 lessons_round2 §5.2 教训）

### 1.1 第二轮为何停在 977us（未达 605us）
lessons_round2 §2 已定性：977us→605us 的差距，主因是第二轮**为隔离流水变量而刻意排除的 MM1 K 加载路径**（main 用 `LoadNzL1ToZnL0BWithTranspose` 大块加载，第二轮沿用裸 `LoadData2D` 128 行小块）。本轮正面回收这一项。

### 1.2 本轮抽取的增量到底改变了什么（量化，basic_case：seq=1024, dim=128, s2BaseSize=512, mBaseSize=512）
单个任务 MM1 内（qRows=512, s2Rows=512, BASE_K=128, dim=128 → kTiles=1, kRemain=0）：

| 项 | 第二轮（128 行 K 块） | 本轮（256 行 K 块） | 变化 |
|:--|:--|:--|:--|
| K 的 GM→L1 DataCopy 次数 | 4（每次 128 行） | **2（每次 256 行）** | **减半**，单次传输更大 |
| K 的 GM→L1 总字节 | 512×128×2=128KB | 128KB | **不变**（每行只搬一次） |
| 128×128 Mmad tile 数 | 4×4=16 | 16 | 不变 |
| K 的 L1→L0B 微指令数 | 16（每 tile 1 条连续 `LoadData2D`） | **128（每 tile 8 条 C0 分块 `LoadData2D`）** | **增加**（转置抽取的代价） |
| Q 的 L1→L0A 加载 | 16 tile × 8 = 128 条 | 128 条 | **不变**（Q 路径本轮不动） |

**关键诚实结论：本轮不减少任何 GM 流量**。收益来自两点：(a) MTE2（GM→L1）传输从 4 次大粒度合并为 2 次更大粒度，摊薄每次 DMA 的固定启动开销；(b) kpQueL1_ 的 ping-pong 周期在 MM1 内从 4 次减为 2 次，减少跨流水 flag 与队列调度开销、加深与计算的重叠。**代价是** K 的 L1→L0B 微指令数增加（16→128 条 MTE1）。因此这是一次「用更便宜的片上 MTE1 微指令换更贵的 MTE2 大块传输次数」的权衡，净收益取决于 MTE2 是否为 MM1 瓶颈。

### 1.3 这是「单增量上界」而非「累计上界」（不重蹈第二轮高估覆辙）
lessons_round2 §5.2 明确告诫：不要把「某单一增量」等同于「main 全部剩余增量」。977us→605us 的差距实际由**多个独立增量**构成，至少包括：
- (i) **MM1 K 大块转置加载**（本轮抽取）；
- (ii) **MM1 Q→L0A 单指令加载**（main 的 `LoadNzL1ToZzL0A`，把 Q 的 128 条 `LoadData2D` 降为 16 条，本轮**未抽取**）；
- (iii) **MM2 P/V 大块加载**（main 的 `KL1_SPLIT=256`，本轮**未抽取**）。

本轮只回收 (i)。因此**本轮目标绝不是 605us**，而是「在 977us 上拿到 (i) 这一项的保守增量」。(ii)(iii) 留给第四/五轮。详见 §8 的保守估计。

---

## 2. 增量优化点总览（一图）

```
第二轮(977us)                         本轮
────────────                          ──────────────────────────────
K 外层步长 = BLOCK_N(128)        →     K 外层步长 = nL1Size(dim<=128?256:128)
每 128 行 K: 1 次 GM->L1              每 256 行 K: 1 次 GM->L1（次数减半，块更大）
K->L0B: 裸 LoadData2D 整块连续拷贝 →   K->L0B: LoadNzL1ToZnL0BWithTranspose
                                       （256 行 L1 块里按 128 行 n 子块 C0 分块抽取）
(Q->L0A 逐行 LoadData2D)              (Q->L0A 逐行 LoadData2D  —— 不变)
(MM2 / 流水 / 同步)                   (MM2 / 流水 / 同步        —— 全部不变)
kpQueL1_ 单槽 = BLOCK_N*dim          kpQueL1_ 单槽 = (dim<=128?256:128)*dim（dim=128 时 32KB->64KB）
```

> **生效范围（诚实标注）：** 本优化仅对 `dim ≤ BASE_K(128)` 路径生效（实测用例中即 `dim=128`，含 basic_case）。对 `dim > 128`（用例中 256/512）路径，`nL1Size` 自适应取 `BLOCK_N=128`，`colC0Stride==n`，`LoadNzL1ToZnL0BWithTranspose` 走单指令分支，**与第二轮逐字节等价、零改变、零风险**。故聚合性能提升只体现在 dim=128 的用例上。

---

## 3. ComputeMM1 改造（伪代码，实现者逐字落地）

> 下面是**改造后**的 `ComputeMM1` 完整结构。与第二轮的差异已用 `// [改]` / `// [新]` / `// [不变]` 标注。实现者**只改 MM1**，函数签名保持第二轮 `ComputeMM1(int bz, int kvHead, uint32_t s2Start, uint32_t s2Rows, uint32_t qRows)` 不变（**不**学 main 增加 `qLocalOffset` 形参——第二轮 Q 寻址用 `mStart/C0+i` 逐行，本轮不动）。

```cpp
__aicore__ inline void ComputeMM1(int bz, int kvHead, uint32_t s2Start,
                                  uint32_t s2Rows, uint32_t qRows)
{
    auto sSlot = sQueue_.ProducerAcquire();            // [不变] 跨核同步契约
    uint32_t dim        = tiling_.dim;
    uint32_t kvSeqLen   = tiling_.kvSeqLen;
    uint32_t outerCols  = tiling_.s2BaseSize;
    uint32_t qRowsAlign = AlignUp(qRows, C0);
    uint32_t qC0Stride  = qRowsAlign;                  // [不变] 常驻 Q 块 NZ 列步长
    uint32_t kTiles     = dim / BASE_K;
    uint32_t kRemain    = dim % BASE_K;
    // [新] K 大块行数：dim<=128 时一次装 256 行 K，否则退化为 128（=第二轮）
    uint32_t nL1Size    = (dim <= BASE_K) ? 256U : BLOCK_N;   // 256 or 128

    LocalTensor<QType> qL1 = qBufL1_.Get<QType>();     // [不变]

    // ---- 外层：K 大块（nL1Size 行）GM->L1，每块一次 ----
    for (uint32_t nL1Start = 0; nL1Start < s2Rows; nL1Start += nL1Size) {   // [改] 步长 128->nL1Size
        uint32_t kvRows      = MinU32(nL1Size, s2Rows - nL1Start);
        uint32_t kvRowsAlign = AlignUp(kvRows, C0);

        // K 大块 GM->L1（TQue ping-pong，自动 MTE2<->MTE1 flag） [不变机制，块更大]
        LocalTensor<QType> kvL1 = kpQueL1_.AllocTensor<QType>();
        uint64_t kOffset = ((uint64_t)bz * tiling_.nkv * kvSeqLen
                          + (uint64_t)kvHead * kvSeqLen
                          + (uint64_t)(s2Start + nL1Start)) * dim;
        LoadNdGmToNzL1(kvL1, kGm_[kOffset], kvRows, dim, dim, kvRowsAlign);
        kpQueL1_.EnQue(kvL1);
        kvL1 = kpQueL1_.DeQue<QType>();

        // ---- 中层：Q 微块（128 行）沿 qRows ----  [不变]
        for (uint32_t mStart = 0; mStart < qRows; mStart += BLOCK_M) {
            uint32_t mRows      = MinU32(BLOCK_M, qRows - mStart);
            uint32_t mRowsAlign = AlignUp(mRows, C0);

            // [新] 内层：n 子块（128 行）沿当前 K 大块的 kvRows
            for (uint32_t nL0Start = 0; nL0Start < kvRows; nL0Start += BLOCK_N) {
                uint32_t nRows      = MinU32(BLOCK_N, kvRows - nL0Start);
                uint32_t nRowsAlign = AlignUp(nRows, C0);

                LocalTensor<float> cL0 = queL0C_.AllocTensor<float>();

                for (uint32_t ki = 0; ki < kTiles; ki++) {
                    // -- Q -> L0A：保持第二轮逐 C0 行 LoadData2D（[不变]，逐字节同基线）--
                    LocalTensor<QType> aL0 = queL0A_.AllocTensor<QType>();
                    {
                        uint64_t qL1Off = (uint64_t)ki * BASE_K * qC0Stride;
                        for (uint32_t i = 0; i < mRowsAlign / C0; i++) {
                            LoadData2DParams p;
                            p.startIndex  = mStart / C0 + i;
                            p.repeatTimes = BASE_K / C0;
                            p.srcStride   = qC0Stride / C0;
                            p.dstGap      = 0;
                            p.ifTranspose = false;
                            LoadData(aL0[C0 * i * BASE_K], qL1[qL1Off], p);
                        }
                    }
                    queL0A_.EnQue(aL0);

                    // -- K -> L0B：[改] 用转置 helper 从大块按 n 子块抽取 --
                    LocalTensor<QType> bL0 = queL0B_.AllocTensor<QType>();
                    {
                        // src 偏移：第 ki 个 K-tile 起点 + n 方向 nL0Start 子块偏移
                        uint64_t kL1Off = (uint64_t)ki * kvRowsAlign * BASE_K
                                        + (uint64_t)C0 * nL0Start;
                        LoadNzL1ToZnL0BWithTranspose(bL0, kvL1[kL1Off],
                                                     BASE_K, nRowsAlign, kvRowsAlign);
                    }
                    queL0B_.EnQue(bL0);

                    aL0 = queL0A_.DeQue<QType>();
                    bL0 = queL0B_.DeQue<QType>();

                    MmadParams mp;
                    mp.m = mRowsAlign;
                    mp.n = nRowsAlign;          // [改] 用 n 子块行数，不再是整 kvRowsAlign
                    mp.k = BASE_K;
                    mp.cmatrixInitVal = (ki == 0);
                    mp.cmatrixSource  = false;
                    PipeBarrier<PIPE_M>();      // [不变] 同 L0C 多 ki 累加序，必须保留
                    Mmad(cL0, aL0, bL0, cL0, mp);
                    queL0A_.FreeTensor(aL0);
                    queL0B_.FreeTensor(bL0);
                }

                if (kRemain > 0) {              // [改] 同上，把 BASE_K 换 kAligned、加 nL0Start 偏移
                    uint32_t kAligned = AlignUp(kRemain, C0);
                    LocalTensor<QType> aL0 = queL0A_.AllocTensor<QType>();
                    {
                        uint64_t qL1Off = (uint64_t)kTiles * BASE_K * qC0Stride;
                        for (uint32_t i = 0; i < mRowsAlign / C0; i++) {
                            LoadData2DParams p;
                            p.startIndex  = mStart / C0 + i;
                            p.repeatTimes = kAligned / C0;
                            p.srcStride   = qC0Stride / C0;
                            p.dstGap      = 0;
                            p.ifTranspose = false;
                            LoadData(aL0[C0 * i * kAligned], qL1[qL1Off], p);
                        }
                    }
                    queL0A_.EnQue(aL0);

                    LocalTensor<QType> bL0 = queL0B_.AllocTensor<QType>();
                    {
                        uint64_t kL1Off = (uint64_t)kTiles * kvRowsAlign * BASE_K
                                        + (uint64_t)C0 * nL0Start;
                        LoadNzL1ToZnL0BWithTranspose(bL0, kvL1[kL1Off],
                                                     kAligned, nRowsAlign, kvRowsAlign);
                    }
                    queL0B_.EnQue(bL0);

                    aL0 = queL0A_.DeQue<QType>();
                    bL0 = queL0B_.DeQue<QType>();

                    MmadParams mp;
                    mp.m = mRowsAlign; mp.n = nRowsAlign; mp.k = kAligned;
                    mp.cmatrixInitVal = (kTiles == 0); mp.cmatrixSource = false;
                    PipeBarrier<PIPE_M>();
                    Mmad(cL0, aL0, bL0, cL0, mp);
                    queL0A_.FreeTensor(aL0);
                    queL0B_.FreeTensor(bL0);
                }

                queL0C_.EnQue(cL0);
                cL0 = queL0C_.DeQue<float>();

                // L0C(mRows x nRowsAlign) -> wsS slot at (mStart, nL1Start+nL0Start)
                FixpipeParamsV220 fixParams;
                fixParams.mSize       = mRows;
                fixParams.nSize       = nRowsAlign;     // [改] n 子块
                fixParams.srcStride   = mRowsAlign;
                fixParams.dstStride   = outerCols;
                fixParams.ndNum       = 1;
                fixParams.srcNdStride = 0;
                fixParams.dstNdStride = 0;
                // [改] 列偏移加上 nL1Start + nL0Start（大块内子块）
                Fixpipe(sSlot[(uint64_t)mStart * outerCols + nL1Start + nL0Start],
                        cL0, fixParams);
                queL0C_.FreeTensor(cL0);
            }   // n 子块
        }       // Q 微块
        kpQueL1_.FreeTensor(kvL1);          // [不变] 全部 L0 load 发起后才 Free
    }           // K 大块
    sQueue_.ProducerReleaseFix();           // [不变] 跨核同步契约
}
```

> **循环结构差异总结（三层 vs 三层）：** 第二轮是「K 微块(128) → Q 微块 → ki」三层，K 微块即 L0B 的 n 维。本轮变成「K 大块(256) → Q 微块 → n 子块(128) → ki」四层，多出的 **n 子块层** 把 256 行 L1 大块切回 128 行喂给 Mmad（Mmad 的 n 仍是 128，硬件约束不变）。Fixpipe 的目标列偏移因此要带 `nL1Start + nL0Start` 两段。

---

## 4. 强制章节：转置加载 helper 的契约级伪代码（盲实现最易错处）

> 基线 `matmul_tile.h` **没有** `LoadNzL1ToZnL0BWithTranspose`（已核实：基线只有 `LoadNdGmToNzL1`×2、`LoadNzL1ToZzL0A`、`LoadNzL1ToZnL0B`、`FixpipeNzL0cToNdGm`、`FixpipeNzL0cToNdGmStride`）。实现 subagent 看不到 main，必须**逐字节按本节实现并新增**该 helper 到 `matmul_tile.h`。这是本轮最高风险面（stride/寻址，对应 lessons_round1 §4 的盲区类别）。

### 4.1 helper 完整实现（实现者逐字落地）

```cpp
// L1(Nz) -> L0B(Zn)，从「比 L0B 子块更宽的 L1 大块」里按 n 子块抽取。
// 参数语义：
//   dst         : L0B 目标（Zn 排布），单子块 k×n
//   src         : L1 源指针，已含 n 子块列偏移（调用方传 kvL1[... + C0*nL0Start]）
//   k           : 当前 K-tile 的 k 维（BASE_K=128，尾块为 kAligned）
//   n           : 当前 n 子块对齐行数（nRowsAlign，常为 128，尾块可能 <128 但 %C0==0）
//   colC0Stride : L1 大块的 NZ 列步长 = kvRowsAlign（256 或尾块对齐值）
template<typename T>
__aicore__ inline void LoadNzL1ToZnL0BWithTranspose(
        const AscendC::LocalTensor<T> &dst,
        const AscendC::LocalTensor<T> &src,
        uint32_t k, uint32_t n, uint32_t colC0Stride)
{
    constexpr uint32_t c0 = 32 / sizeof(T);     // half/bf16 -> 16
    AscendC::LoadData2DParams p;
    p.startIndex  = 0;
    p.srcStride   = 1;
    p.dstGap      = 0;
    p.ifTranspose = false;
    if (colC0Stride == n) {
        // 退化分支：L1 块宽度恰等于 n 子块 -> 与基线裸 LoadData2D 单指令逐字节等价
        p.repeatTimes = (k / c0) * (n / c0);
        AscendC::LoadData(dst, src, p);
    } else {
        // 大块分支：L1 块宽度 colC0Stride > n，按 C0 行分块循环抽取
        p.repeatTimes = n / c0;
        for (uint32_t i = 0; i < (k / c0); ++i) {
            AscendC::LoadData(dst[(uint64_t)n * i * c0],
                              src[(uint64_t)colC0Stride * i * c0], p);
        }
    }
}
```

### 4.2 LoadData2DParams 逐字段契约（实现者据此自检，不可臆测）

| 字段 | 取值 | 含义 / 为什么 |
|:--|:--|:--|
| `startIndex` | `0` | 起始分形索引。调用方已通过 `src[...]` 把 n 子块/k-tile 偏移算进指针，故 helper 内恒 0。 |
| `srcStride`  | `1` | 相邻 fractal（16×16）在 L1 NZ 中的源步长（以 fractal 为单位）。连续抽取，恒 1。 |
| `dstGap`     | `0` | L0B 目标 fractal 间无间隙，连续写。 |
| `ifTranspose`| `false` | **不在 LoadData 内做 16×16 转置**。Kᵀ 的转置语义由 NZ 排布 + Mmad 的 B 矩阵读法天然完成，这里只是「抽取」不是「转置数据」。命名里的 Transpose 指它服务于 S=Q@Kᵀ 的 B 矩阵抽取，**取值务必 false**。 |
| `repeatTimes`（退化分支）| `(k/c0)*(n/c0)` | 整块一次性搬 `k×n` 个元素 = `(k/16)*(n/16)` 个 fractal。 |
| `repeatTimes`（大块分支）| `n/c0` | 每个 C0 行（16 行 k）只搬 `n/16` 个 fractal。 |
| 循环次数（大块分支）| `k/c0` | 沿 k 方向分 `k/16` 段；k=128 时 8 次（与 §1.2 表「8 条 C0 分块」一致）。 |
| `dst` 偏移 | `n * i * c0` | 第 i 个 C0 段在 L0B 里的元素偏移 = `n(列)×16(行)×i`，连续排布。 |
| `src` 偏移 | `colC0Stride * i * c0` | 第 i 个 C0 段在 L1 里跳 `colC0Stride×16×i` 个元素——**关键**：因为 L1 大块列步长是 256（colC0Stride），不是 128（n），所以不能用 `n*i*c0`，否则读错位（这正是大块分支与退化分支唯一的本质差异）。 |

### 4.3 它如何替换第二轮 MM1 里的裸 LoadData2D

第二轮 MM1 的 K→L0B（基线 cube.h 第 128–138 行）是：
```cpp
LocalTensor<QType> bL0 = queL0B_.AllocTensor<QType>();
uint64_t kL1Off = (uint64_t)ki * kvRowsAlign * BASE_K;   // kvRowsAlign 当时 = 128
LoadData2DParams p;
p.startIndex = 0; p.repeatTimes = (BASE_K/C0)*(kvRowsAlign/C0);
p.srcStride = 1;  p.dstGap = 0; p.ifTranspose = false;
LoadData(bL0, kvL1[kL1Off], p);
```
本轮替换为（§3 已给）：
```cpp
uint64_t kL1Off = (uint64_t)ki * kvRowsAlign * BASE_K + (uint64_t)C0 * nL0Start;
LoadNzL1ToZnL0BWithTranspose(bL0, kvL1[kL1Off], BASE_K, nRowsAlign, kvRowsAlign);
```
- **当 dim>128（kvRowsAlign==BLOCK_N==128，nL0Start 恒 0）：** `colC0Stride==n==128`，走退化分支，`repeatTimes=(128/16)*(128/16)`，且 `kL1Off` 的 `C0*nL0Start==0` —— 与第二轮**逐字节完全相同**。零风险。
- **当 dim≤128（kvRowsAlign==256）：** `colC0Stride=256 ≠ n=128`，走大块分支，按 8 段 C0 抽取，`kL1Off` 多出 `C0*nL0Start` 定位到大块内第二个 128 行子块。这是本轮真正的新代码路径。

> **自检要点（实现者务必逐条核对）：**
> 1. helper 第三参数 `k` 传 `BASE_K`（或尾块 `kAligned`），**不是** kvRows；第四参数 `n` 传 `nRowsAlign`（当前 n 子块）；第五参数 `colC0Stride` 传 `kvRowsAlign`（L1 大块宽度，256）。三者顺序极易搞反。
> 2. `src` 指针偏移里的 `C0 * nL0Start`：`C0=16`，n 子块沿列方向，每跨一个 128 行子块需跳 `16×128` 个元素？**否**——NZ 排布下 n 子块偏移是 `C0 * nL0Start = 16 * nL0Start`（nL0Start 以行计，第二子块 nL0Start=128 → 偏移 2048 元素 = 一个 fractal 列条）。务必照 §3 的 `(uint64_t)C0 * nL0Start` 写，不要自行推导成 `nL0Start * something_else`。
> 3. Mmad 的 `mp.n` 改用 `nRowsAlign`（128），**不是** kvRowsAlign（256）。否则 Mmad 维度与 L0B 实际子块不符。

---

## 5. 同步契约：完全保持第二轮，不动（强制声明）

本轮**只改 L1→L0B 的加载指令形态**，不改任何同步语义。以下契约**逐字沿用第二轮 design_doc_round2.md §4，实现者不得改动**：

- **跨核 CrossCore（§4.A）：** SIG_S/P/O_READY 三信号、`ProducerAcquire/ProducerReleaseFix/ProducerReleaseMte3/ConsumerAcquire` 的调用点与配对计数（每信号各 s2OuterBlocks 次，prologue 只 Producer、epilogue 只 Consumer），**完全不变**。MM1 入口仍 `sQueue_.ProducerAcquire()`、出口仍 `sQueue_.ProducerReleaseFix()`，位置不动。
- **Cube L1/L0 TQue 自动同步（§4.B）：** `kpQueL1_` 深度 3、`AllocTensor→LoadNd→EnQue→DeQue→...→FreeTensor` 的 ping-pong 流程**不变**。本轮只是把 DeQue 之后、FreeTensor 之前的「对 kvL1 的若干次 MTE1 读」从「1 次裸 LoadData2D」变成「n 子块 × ki 次 `LoadNzL1ToZnL0BWithTranspose`（内部含 C0 循环）」。**所有这些 MTE1 读仍发生在同一个 DeQue 与 FreeTensor 之间**，TQue 的 MTE2↔MTE1 flag 覆盖范围不变 —— FreeTensor 仍在「该 K 大块的全部 n 子块、全部 ki 的 L0B load 都发起之后」调用（§3 伪代码已把 FreeTensor 放在最外层 K 大块循环末尾，位置正确）。
- **同 L0C 多次 Mmad 累加序：** `PipeBarrier<PIPE_M>()` 在 ki 循环内**保留不动**（同 cL0 累加）。注意本轮 n 子块之间用的是**不同** cL0（每个 n 子块 AllocTensor 一次新 cL0），它们之间靠 queL0C_ 深度 2 的 ping-pong flag 隔离，无需额外 barrier。
- **Vec 侧 UB 队列（§4.C）：** 完全不碰（本轮不动 vec.h）。

> **一句话契约：本轮对同步系统是「透明」的——把一条 MTE1 指令换成一簇 MTE1 指令，不增删任何 SetFlag/WaitFlag/CrossCore/EnQue/DeQue/FreeTensor。** 实现者若发现自己在动 flag，说明改错了。

---

## 6. 容量校验（L0B/L1 占用变化，必须 ≤ L0B 64KB / L1 512KB）

数据类型 half/bf16（sizeof=2，C0=16）。主路径 dim=128, s2BaseSize=512, mBaseSize=512。

### 6.1 L0B 占用：**不变**（关键结论）
- 第二轮 L0B 单槽 = `BASE_K × BLOCK_N = 128×128 half = 32KB`，深度 2 = 64KB（恰满）。
- 本轮 L0B 仍按 **n 子块（128）** 喂 Mmad，`LoadNzL1ToZnL0BWithTranspose` 的 dst 一次写 `k×n=128×128`。**L0B 单槽仍 32KB，深度 2 仍 64KB，零变化。** 大块只发生在 L1，不发生在 L0B。

### 6.2 L1 占用：**kpQueL1_ 单槽翻倍（dim=128 时）**
- 第二轮 kpQueL1_ 单槽 = `max(BLOCK_N×dim, BLOCK_M×BLOCK_N) = max(128×128, 128×128) = 128×128 half = 32KB`，深度 3 = 96KB。
- 本轮 MM1 的 K 大块需 `nL1Size×dim = 256×128 half = 64KB`；MM2 的 P 块仍 `BLOCK_M×BLOCK_N=32KB`（MM2 不改）。故 **kpSlot = max(256×128, 128×128) = 64KB**，深度 3 = **192KB**。
- L1 其余：qBufL1_（mBaseSize×dim=512×128 half=128KB）、vQueL1_（BLOCK_N×dim=128×128×2槽=64KB）。
- **L1 合计 = 192 + 128 + 64 = 384KB ≤ 512KB ✓**（余 128KB，安全）。

> **InitBuffers 改法（实现者照此）：** 把 `uint32_t kElems = BLOCK_N * dim;` 改为 `uint32_t kElems = ((dim <= BASE_K) ? 256U : BLOCK_N) * dim;`（即 `nL1Size * dim`，与 MM1 的 nL1Size 公式严格一致）。`pElems = BLOCK_M * BLOCK_N` 不变。`kpSlot = max(kElems, pElems)`。**严禁**把 nL1Size 写死 256——dim>128 时必须退回 128，否则浪费 L1 且与 MM1 循环步长不一致。
> **dim 边界自检：** 通用用例含 dim=256/512（>128），此时 nL1Size=128，kElems=128×256 或 128×512 = 64KB 或 128KB。需重算：dim=512 时 kpSlot=128×512×2=128KB，深度3=384KB；qBufL1_ 此时 mBaseSize 较小（短 Q 路径 mBaseSize≤256）。实现者必须用**实际 dim** 算 kElems，不要假设 dim=128。dim=512 长 Q 不在 basic_case，但通用用例会触发，InitBuffers 公式必须 dim 自适应（已由 `kElems=nL1Size*dim` 保证）。

---

## 7. 最小改动边界（实现者只动这两个文件）

| 文件 | 改动 | 不改 |
|:--|:--|:--|
| `matmul_tile.h` | **新增** `LoadNzL1ToZnL0BWithTranspose`（§4.1 逐字节） | 其余 helper 全部不动 |
| `flash_attention_cube.h` | (a) `ComputeMM1` 按 §3 改造（外层步长 nL1Size、新增 n 子块层、K→L0B 改调 helper、Fixpipe 列偏移加 nL1Start+nL0Start、Mmad.n 改 nRowsAlign）；(b) `InitBuffers` 的 kElems 按 §6.2 改 | `ComputeMM2`、`LoadQ`、`Init`、所有 buffer 声明（kpQueL1_/vQueL1_/queL0A/B/C 深度与类型）、私有成员 —— **全部不动** |
| `flash_attention_kernel.h` | **不改**（顶层流水循环、MM1 调用签名不变） | 全部 |
| `flash_attention_vec.h` | **不改** | 全部 |
| `flash_attention_tiling.h/.cpp` | **不改**（nL1Size 在 kernel 内由 dim 推导，不进 tiling） | 全部 |
| `workspace_queue.h`、`kernel_common.h` | **不改** | 全部 |

> **签名约束（重要）：** 第二轮 `ComputeMM1` 签名是 5 参 `(bz, kvHead, s2Start, s2Rows, qRows)`，`flash_attention_kernel.h` 按此调用。本轮**保持 5 参不变**，不引入 main 的 `qLocalOffset`。`nL1Size` 在函数体内由 `dim` 局部推导，不入参、不入 tiling。这样 kernel.h 零改动。

---

## 8. 待验证假设：保守收益估计与风险（吸取 lessons_round2 §5.2「不高估上界」教训）

**基线锚定：本节所有收益相对第二轮 977us（commit 0dc4b54），绝不锚定 605us/1590us/2391us。**

### 8.1 保守收益估计（诚实区分单增量 vs 累计）
- **本轮目标 ≠ 605us。** 如 §1.3 所述，977us→605us 的 372us 差距由至少三个独立增量 (i)(ii)(iii) 构成，本轮只回收 (i)「MM1 K 大块转置加载」。
- **(i) 的收益机理（§1.2）：** 不减 GM 流量，只把 MM1 内 K 的 GM→L1 传输次数减半（4→2，dim=128 时）、加深 ping-pong 重叠；代价是 K 的 L1→L0B MTE1 微指令增多（16→128）。这是「MTE2 次数 ↓ / MTE1 指令数 ↑」的权衡。
- **保守区间估计：977us → 880~940us（约 1.04~1.10x）。** 理由：
  - MM1 只是整个 kernel 的一部分（还有 MM2 + Vec1/Vec2 + 跨核流水），(i) 只作用于 MM1 的 K-load 子段；
  - dim=128 路径才生效（见 §2 标注），通用用例里 dim=256/512 的任务**零收益**，聚合提升被稀释；
  - 软流水已把 MTE2 大量藏到计算背后（第二轮的核心收益），MM1 K 的 MTE2 次数减半的边际收益因此**被流水重叠提前吃掉一部分**——这是最可能让收益偏小的因素；
  - 增多的 128 条 MTE1 微指令若与 Mmad 抢 MTE1 端口，可能**部分抵消** MTE2 的收益，极端情况下净收益趋近 0。
- **乐观上界（不作为目标）：若 MM1 的 MTE2 恰是关键路径瓶颈，可能到 977→820us（约 1.19x）。** 但基于「流水已重叠 MTE2」的判断，我**倾向保守端**，预期落在 900us 附近。
- **明确预告：本轮单增量很可能只贡献个位数到 ~10% 的提升，不排除持平。** 这与第二轮把「流水增量」误当「全部增量」导致高估的教训相反——本轮宁可低估。真正逼近 605us 需要叠加第四轮 (ii) Q→L0A 单指令、第五轮 (iii) MM2 大块加载。

### 8.2 主要风险点（按概率排序）
1. **stride/寻址错位（最高风险，精度 FAIL 而非死锁）：** `LoadNzL1ToZnL0BWithTranspose` 的 `src` 偏移 `colC0Stride*i*c0` vs `dst` 偏移 `n*i*c0`、调用处 `kL1Off` 的 `C0*nL0Start`、第三/四/五参数顺序（k/n/colC0Stride）——任一错位都会让 K 子块读错，精度 mismatch。§4.2/§4.3 已给逐字段契约 + 自检三条，但这是盲实现历史最易翻车处（lessons_round1 §4）。
2. **Fixpipe 目标列偏移漏加 nL0Start：** 本轮 Fixpipe dst 列偏移从第二轮的 `nStart` 变为 `nL1Start + nL0Start`（两段）。漏掉 nL0Start → 大块内第二个 n 子块写回覆盖第一个 → 精度错且只在 dim≤128 体现。
3. **Mmad.n 用错（256 vs 128）：** §3/§4.3 自检点 3。用 kvRowsAlign(256) 而非 nRowsAlign(128) → Mmad 维度越界或读脏。
4. **InitBuffers kElems 没跟着 nL1Size 改：** 若 InitBuffers 仍按 `BLOCK_N*dim=32KB` 分配，而 MM1 按 256 行写 64KB → L1 越界踩踏（dim=128 时）。§6.2 已强制「kElems=nL1Size*dim」公式一致性。
5. **helper 退化分支边界（colC0Stride==n）误判：** dim>128 时必须走退化分支与第二轮逐字节等价。若实现者把 if 条件写错（如写成 `colC0Stride<=n` 或漏掉退化分支），dim>128 用例会回归。§4.1 的 if 条件须照抄。
6. **kRemain 尾块路径（dim 非 128 整数倍）：** 通用用例 dim=256/512 是 128 整数倍（kRemain=0），但 dim=473 之类不在用例。当前用例 kRemain 恒 0，尾块分支不触发；实现者仍须把尾块分支按 §3 写对（防御性），但不是本轮验证重点。

### 8.3 验证建议（交给主控/debugger）
- **先 basic_case（seq=1024, dim=128）：** 这是唯一稳定触发大块分支（nL1Size=256）的用例，精度必须 PASS（REL ~1e-3，与第二轮同量级，因不改算法）。若 FAIL，优先查风险 1/2/3（stride/Fixpipe/Mmad.n）。
- **再全量：** 确认 dim>128 用例（256/512）与第二轮**逐字节一致**（走退化分支），不应有任何精度或性能回归——若回归，查风险 5（退化分支条件）。
- **性能：** 与 977us 对比。若落在 900~940us 属预期（拿到 (i) 的保守增量）。若 ≥977us（持平或退化），说明 MTE1 微指令增多抵消了 MTE2 收益（§8.1 已预告此可能），**不算 bug**，是本单增量的真实边际——记录后转入第四轮叠加 (ii)。若 <860us，超预期，复核是否误掺其他改动。
- **死锁排查：** 本轮不动同步，理论上不该死锁；若 TIMEOUT，首查是否误改了 §5 的 TQue/CrossCore 调用（说明越界改了同步）。

---

## 9. 与前两轮范式的衔接（自检清单）

| lessons 教训 | 本轮落实 |
|:--|:--|
| R1§5：基线锚定要正确 | §0/§8 全程锚定 977us |
| R1§4：stride/寻址必须契约级给定 | §4.2 逐字段表 + §4.3 替换对照 + §8.2 风险1 |
| R1§4：多方案二选一要给默认 | 本轮只给方案 A（自补 helper），无二义（main 也是 A） |
| R2§5.2：不把单增量当累计上界 | §1.3 拆三子项，§8.1 明确「目标≠605us，预期~900us」 |
| R2§5.3：动 L0B 加载要写 LoadData2DParams 契约 | §4.1/§4.2 完整给出 |
| R2§5：同步契约延续不动 | §5 强制声明「对同步透明」 |
| R2§5.4：单变量隔离 | §0 声明「nL1Size+转置 helper 是同一逻辑变量」，不掺 Q/MM2 |

> **本轮与 main 的唯一对照差异（供主控复核归因）：** main 的 MM1 同时用了 (i) K 转置大块加载 **和** (ii) Q 的 `LoadNzL1ToZzL0A` 单指令加载。本轮**只取 (i)，Q 路径保持第二轮逐行 LoadData2D**。因此本轮若达 ~900us，与 main 的 605us 差距主要落在 (ii)+(iii)，归因清晰、可独立验证。
