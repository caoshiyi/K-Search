# FlashAttention 性能优化设计文档

> **本轮优化点：QKV 两级分块 + L1 大块复用**
> 本文只描述这一个优化点。流水线 / double buffer / TQue 多缓冲 / 搬运-计算重叠等其他优化**不在本轮范围**，留给后续轮次。实现者应在现有单缓冲（TBuf）结构上落地两级分块，不要引入多 buffer 流水。

---

## 0. 问题背景与优化动机

### 0.1 当前实现（基线）的结构
基线 kernel 采用**单级固定 128 微块**调度：

- 外层循环：把 Q 序列按 `BLOCK_M = 128` 行切成 `seqBlocks = ceil(qSeqLenAlign / 128)` 个 Q 块，每个核领若干 Q 块任务。
- 内层循环：对每个 Q 块，沿 KV 方向按 `BLOCK_N = 128` 步进，循环 `kvLoops = ceil(kvSeqLen / 128)` 次。
- 每次 KV 迭代里：
  - MM1 从 **GM** 加载一个 `128 × dim` 的 K tile 到 L1，算 `S = Q · Kᵀ`（128×128）。
  - MM2 从 **GM** 加载对应的 `128 × dim` 的 V tile 到 L1，算 `O_tile = P · V`。

### 0.2 性能根因
seq=1024、dim=128、shape `4,32,4,1024,1024,128,fp16` 下：
- 每个 head 有 `8` 个 Q 块（1024/128），KV 也有 8 个 tile。
- 因为外层是 Q 块、内层是 KV，**每处理一个 Q 块就把全部 K、V 从 GM 完整重搬一遍** → K、V 各被重复搬运 **8 次**。
- K/V 的 GM→L1 搬运量 = `8 × (kvSeqLen × dim)`，是理论下界（搬 1 次）的 8 倍。

### 0.3 本轮优化思路（一句话）
**把 Q 方向和 KV 方向都升级为「外层大块 + 内层 128 微块」两级分块**，让一个大的 K/V 块（`s2BaseSize` 行）一次性搬进 L1 后，被同一任务内的多个 Q 微块（共 `mBaseSize` 行）反复复用，从而把 K/V 的 GM 重复搬运次数从 `qOuterBlocks` 降到 1（每个 KV 外层块只搬一次）。

> **重要的诚实提示（见文末「待验证假设」）**：本工作区已有的前序实验表明，单独引入「两级分块 + L1 复用」而**不带流水**时，性能收益可能接近 0（搬运不是本 kernel 在该 shape 下的唯一瓶颈，串行同步会吃掉省下的搬运时间）。本轮仍按要求独立实现该优化点，作为后续流水优化的**结构前提**。

---

## 1. 两级分块的粒度定义与推荐取值

引入两个新的 tiling 粒度参数（区别于固定常量 `BLOCK_M = BLOCK_N = BASE_K = 128`）：

| 参数 | 含义 | 推荐取值（本 shape） | 理由 |
|------|------|------|------|
| `mBaseSize` | **Q 方向外层大块**行数：一个调度任务一次处理多少行 Q | `512`（dim≤192 时） | 一个任务覆盖更多 Q 行，使一次搬入 L1 的 K/V 被更多 Q 微块复用；512=4×128，正好 4 个 M 微块 |
| `s2BaseSize` | **KV 方向外层大块**行数：online-softmax 一次迭代覆盖多少 KV 行 | `512`（qSeqLen>16 时） | 一个 KV 外层块一次搬进 L1，被该任务全部 Q 微块复用；512=4×128 |
| `BLOCK_M` | M 方向**内层微块**（Mmad 的 m） | `128`（固定） | Cube L0A/L0C 的基本计算粒度 |
| `BLOCK_N` | N 方向**内层微块**（MM1 的 n / MM2 的 k 切分） | `128`（固定） | Cube L0B 基本计算粒度 |
| `BASE_K` | K 方向（reduce 维 = dim）**内层微块** | `128`（固定） | dim=128 恰好一个 BASE_K |

派生量（host 侧 tiling 计算，kernel 侧从 tiling 读取）：
- `qOuterBlocks = ceil(qSeqLenAlign / mBaseSize)` —— Q 外层块数。本 shape：1024/512 = 2。
- `s2OuterBlocks = ceil(kvSeqLen / s2BaseSize)` —— KV 外层块数。本 shape：1024/512 = 2。
- 任务总数 `totalGSq = groupNum × qOuterBlocks`，`totalBNkv = batch × nkv`，与基线相同的核间分配逻辑（线性切分到 `usedCoreNum` 个核，`bNkvEnd[]/gSqEnd[]`）。

### 1.1 取值约束与选择函数（host 侧）
推荐用两个 host 辅助函数动态选择，而不是写死：

```
SelectS2BaseSize(qSeqLen, groupNum):
    # s2BaseSize 上限 1024：保证 vec 侧 vec1ChunkRows = UB_QUEUE_BYTES/(s2BaseSize*4) >= 8，
    # 使 softmax state 写入地址 32B 对齐；UB 192KB 下 s2BaseSize>1024 会令 vec input queue 超限
    if qSeqLen <= 16: return 1024      # 短 Q：KV 块尽量大
    else:             return 512       # 长 Q（本 shape=1024）：512

SelectMBaseSize(qSeqLen, s2BaseSize):
    base = 512
    if qSeqLen <= 16:                  # 短 Q 时按 s2BaseSize 反比缩 mBaseSize 控 workspace
        if   s2BaseSize <= 512:  base = 512
        elif s2BaseSize <= 1024: base = 256
        elif s2BaseSize <= 2048: base = 128
        else:                    base = 64
    return max(base, BLOCK_M)          # 最小执行微块仍是 128
```

> 关键约束：`mBaseSize` 必须是 `BLOCK_M=128` 的整数倍，`s2BaseSize` 必须是 `BLOCK_N=128` 的整数倍，且 `s2BaseSize <= 1024`（vec 侧 UB 与对齐限制）。


---

## 2. 调度循环结构（kernel 顶层）

每个核遍历分给它的 `(bNkv, gSq)` 任务区间。一个任务 = 一个 `(batch, kvHead, group, qOuterIdx)`，即「某个 head 的某个 Q 外层大块」。

```
for each task (bz, kvHead, groupId, qOuterIdx) assigned to this core:
    qHead     = kvHead * groupNum + groupId
    qRowStart = qOuterIdx * mBaseSize
    qRows     = min(mBaseSize, qSeqLen - qRowStart)   # 尾块可能 < mBaseSize

    if AIC:  cube.LoadQ(bz, qHead, qRowStart, qRows)   # 整个 Q 大块一次搬进 L1
    if AIV:  vec.SetTaskContext(bz, qHead, qRowStart, qRows)

    # KV 外层大块循环（online-softmax 的迭代维）
    for t2 in 0 .. s2OuterBlocks-1:
        s2Start = t2 * s2BaseSize
        s2Rows  = min(s2BaseSize, kvSeqLen - s2Start)   # 尾块可能 < s2BaseSize

        if AIC:
            cube.ComputeMM1(bz, kvHead, s2Start, s2Rows, qRows)   # S = Q·Kᵀ (mBaseSize × s2BaseSize)
            cube.ComputeMM2(bz, kvHead, s2Start, s2Rows, qRows)   # O += P·V
        if AIV:
            vec.ComputeVec1(slot, isFirst=(t2==0), s2Rows)        # scale+mask+online-softmax
            vec.ComputeVec2(slot, isFirst=(t2==0), isLast=(t2==s2OuterBlocks-1))
```

> **本轮不做流水**：直接用「MM1→Vec1→MM2→Vec2」串行同步（沿用基线 `WorkspaceQueue` 的 `CrossCoreSetFlag/WaitFlag` + 同核 `SetWaitFlag<HardEvent>`）。`PRELAUNCH` 可保持，但不是本轮重点；如实现困难，本轮可退化为 PRELAUNCH=0 的纯串行，正确性优先。

任务内 KV 外层只循环 `s2OuterBlocks` 次（本 shape=2），而每个 KV 外层块内部再按 128 切微块——这就是「两级」。

---

## 3. L1 Buffer 布局与放大（Cube 侧核心）

910B L1 容量约 **512 KB**。本轮要把 Q 大块和 K/V 大块都放进 L1，需要重新规划 L1 分配。所有 L1 张量按 **NZ（zN）格式**存放（`LoadNdGmToNzL1` 产出的布局），dim 方向按 `C0=16`（fp16）对齐。

### 3.1 Q 常驻 L1（一个任务搬一次，被所有 KV 外层块复用）
- Q 大块 = `qRows × dim`（≤ `mBaseSize × dim` = 512×128）。
- 为便于按 128 行微块寻址，Q 在 L1 用固定行容量 `Q_L1_ROWS`（推荐 **256**）分段存放：
  - 若 `qRows ≤ 256`：一段。
  - 若 `256 < qRows ≤ 512`：两段，第二段偏移 `Q_L1_ROWS * dim` 个元素。
- NZ 存放时 `dstNzC0Stride = Q_L1_ROWS`（每段固定 256 行的列跨度），dim 列对齐到 `dimAlign`。
- 单段大小 = `Q_L1_ROWS × dimAlign × sizeof(fp16)` = 256×128×2 = **64 KB**；两段 = **128 KB**。
- LoadQ 在**任务开始时调用一次**，整个 KV 外层循环不再重搬 Q。这是「Q 复用」。

### 3.2 K/V 大块进 L1（一个 KV 外层块搬一次，被所有 Q 微块复用）
- K 大块：MM1 里按 `nL1Size`（推荐 256，dim≤BASE_K 时）从 GM 搬 `nL1Size × dim` 进 L1，遍历整个 `s2Rows`。每搬入一块 K，就让**当前任务的全部 Q 微块**（`qRows/128` 个）与它做 Mmad —— 这是「K 复用」的关键：K 在 L1 期间被多个 Q 微块消费。
- V 大块：MM2 里按 `KL1_SPLIT`（推荐 256）从 GM 搬 `KL1_SPLIT × dim` 进 L1，被该任务所有 Q 微块的 `P·V` 复用。
- K/V 的 L1 buffer 单块 = `256 × dimAlign × sizeof(fp16)` = 256×128×2 = **64 KB**。

### 3.3 P（softmax 概率）回搬 L1（MM2 的左矩阵）
- MM2 需要 `P (mBaseSize × s2BaseSize)` 做左矩阵，P 由 vec 侧写回 workspace（GM），MM2 再从 GM 按 `mRows × kL1Size` 搬进 L1。
- P 的 L1 块 = `BLOCK_N × KP_L1_COLS`（推荐 KP_L1_COLS=256）= 128×256×2 = **64 KB**。

### 3.4 L1 容量校验（关键，必须满足 ≤ 512KB）
单缓冲（本轮不 double buffer）峰值同时存在：
- Q 常驻：最多 128 KB（两段 256 行）。
- MM1 阶段：Q(128KB) + K 当前块(64KB) = **192 KB** ✅
- MM2 阶段：Q 已不需（可复用其空间，但保守按仍占）+ P 块(64KB) + V 块(64KB)。即使 Q 仍占 128KB，峰值 = 128+64+64 = **256 KB** ✅
- 加上 L0A/L0B/L0C（各 ≤ 128×128×2/4，KB 级，不在 L1）不影响 L1。

结论：本轮在单缓冲下 L1 峰值约 **256 KB < 512 KB**，安全。若后续加 double buffer 需重新核算。


---

## 4. MM1 两级循环（S = Q · Kᵀ）

输出 `S` 形状 `qRows × s2Rows`（≤ 512×512），写到 workspace_S 的当前 slot，列跨度（dstStride）= `s2BaseSize`（`outerCols`）。

### 4.1 可用的 matmul helper（已核实基线 `matmul_tile.h` 提供）
- `LoadNdGmToNzL1(dst, srcGm, m, n, ld[, dstNzC0Stride])` —— GM(ND)→L1(NZ)。
- `LoadNzL1ToZzL0A(dst, srcL1, m, k, colC0Stride)` —— L1(NZ)→L0A(Zz)，给 Mmad 左矩阵。
- `LoadNzL1ToZnL0B(dst, srcL1, k, n, colC0Stride)` —— L1(NZ)→L0B(Zn)，给 Mmad 右矩阵（**不转置**）。
- `FixpipeNzL0cToNdGm` / `FixpipeNzL0cToNdGmStride` —— L0C→GM。
- **缺失项（重要）**：基线 `matmul_tile.h` **没有** `LoadNzL1ToZnL0BWithTranspose`。MM1 算 `Q·Kᵀ` 需要把 L1 中的 K（`k=dim` 维在 C0 方向、`n=kv行` 维在 M 方向的 NZ 布局）转置加载到 L0B。实现者**有两种选择**：
  - **(A) 自己补一个带转置语义的 helper**（推荐，与基线 `LoadNzL1ToZnL0B` 同签名，多一个按 C0 分块循环 `LoadData2DParams` 的版本）：当 `colC0Stride == n` 时一次 `LoadData`，否则按 `k/c0` 次循环、每次 `src` 偏移 `colC0Stride*i*c0`、`dst` 偏移 `n*i*c0`，`repeatTimes = n/c0`，`ifTranspose=false`。
  - **(B) 沿用基线 MM1 的做法**：基线 MM1 用裸 `LoadData2DParams`（`srcStride = mActAlign/C0`）直接从 qL1 取 Q 切片到 L0A、从 kvL1 顺序取 K 到 L0B，再 `Mmad(m=BLOCK_M, n=kvRowsAlign, k=BASE_K)`。这种写法 K 不需要显式转置 helper（K 以 `kvRows` 为 M 维存放，Mmad 把它当 n 维消费）。**本轮可优先复用 (B) 的加载方式**，只是把循环结构从单级改成两级。

### 4.2 两级循环伪代码
```
ComputeMM1(bz, kvHead, s2Start, s2Rows, qRows):
    sSlot = sQueue.ProducerAcquire()        # workspace_S 当前 slot
    outerCols = s2BaseSize                   # S 在 workspace 的列跨度
    nL1Size = (dim <= BASE_K) ? 256 : BLOCK_N
    kTiles  = dim / BASE_K                    # 本 shape dim=128 → kTiles=1

    # —— 外层：K 大块沿 s2Rows 分段搬进 L1（每段被下面所有 Q 微块复用）——
    for nL1Start in 0 .. s2Rows step nL1Size:
        kvRows = min(nL1Size, s2Rows - nL1Start)
        kvRowsAlign = AlignUp(kvRows, C0)
        kOffset = ((bz*nkv + kvHead)*kvSeqLen + (s2Start + nL1Start)) * dim
        kvL1 = load K[kvRows × dim] from GM → L1(NZ), dstNzC0Stride = kvRowsAlign   # 搬一次

        # —— 中层：Q 微块（128 行）——
        for mL1Start in 0 .. qRows step Q_L1_ROWS:        # 选 Q 在 L1 的哪一段(256行)
            mL1Rows = min(Q_L1_ROWS, qRows - mL1Start)
            qBufId  = mL1Start / Q_L1_ROWS
            for mL0Start in 0 .. mL1Rows step BLOCK_M:    # 128 行 M 微块
                mRows = min(BLOCK_M, mL1Rows - mL0Start)
                mRowsAlign = AlignUp(mRows, C0)

                # —— 内层：N 微块（128 列 KV）——
                for nL0Start in 0 .. kvRows step BLOCK_N:
                    nRows = min(BLOCK_N, kvRows - nL0Start)
                    nRowsAlign = AlignUp(nRows, C0)
                    cL0 = L0C.Alloc()
                    for ki in 0 .. kTiles:                 # reduce 维 dim 分 BASE_K
                        aL0 = load Q slice from qL1[qBufId 段] → L0A(Zz)   # 复用常驻 Q
                        bL0 = load K slice from kvL1 → L0B (转置语义见 4.1)
                        Mmad(cL0, aL0, bL0, m=mRowsAlign, n=nRowsAlign, k=BASE_K,
                             cmatrixInitVal=(ki==0))
                    # dim 尾块 kRemain = dim % BASE_K（本 shape=0，可省）
                    Fixpipe cL0 → sSlot[(mL1Start+mL0Start)*outerCols + nL1Start + nL0Start]
                            (mSize=mRows, nSize=nRowsAlign, srcStride=mRowsAlign, dstStride=outerCols)
    sQueue.ProducerReleaseFix()
```

要点：
- **K 在最外层只搬一次**，被中层/内层的所有 Q 微块复用 → 这是搬运量从 8× 降到 1× 的来源。
- S 直接按 `(mGlobal, nGlobal)` 偏移写进 `mBaseSize × s2BaseSize` 的大 workspace slot，vec 侧据此读。


---

## 5. MM2 两级循环（O = P · V）

输入 `P (qRows × s2Rows)` 来自 vec 写回的 workspace_P slot（列跨度 = `s2BaseSize`）。输出 `O (qRows × dim)` 写 workspace_O slot（列跨度 = `dimAlign`）。reduce 维是 KV 行（`s2Rows`）。

```
ComputeMM2(bz, kvHead, s2Start, s2Rows, qRows):
    pSlot = pQueue.ConsumerAcquire()     # 等 vec1 写好的 P
    oSlot = oQueue.ProducerAcquire()
    outerCols = s2BaseSize
    KL1_SPLIT = 256                       # V/P 沿 KV(reduce) 维分段搬 L1

    for mL0Start in 0 .. qRows step BLOCK_M:        # Q 微块 128 行
        mRows = min(BLOCK_M, qRows - mL0Start);  mRowsAlign = AlignUp(mRows, C0)
        cL0 = L0C.Alloc();  isFirstK = true
        for kL1Start in 0 .. s2Rows step KL1_SPLIT:  # reduce 维分段
            kL1Size = min(KL1_SPLIT, s2Rows - kL1Start)
            kL1SizeAlign = AlignUp(kL1Size, C0)
            # P 段：mRows × kL1Size，从 workspace_P 搬进 L1(NZ)
            pL1 = load P[ pSlot[mL0Start*outerCols + kL1Start] ] → L1, dstNzC0Stride=mRowsAlign
            # V 段：kL1Size × dim，从 GM 搬进 L1(NZ) —— 一次搬，被该 reduce 段复用
            vOffset = ((bz*nkv + kvHead)*kvSeqLen + s2Start + kL1Start) * dim
            vL1 = load V[kL1Size × dim] from GM → L1, dstNzC0Stride = kL1SizeAlign
            for kL0Start in 0 .. kL1Size step BLOCK_N:   # reduce 微块 128
                kL0Size = min(BLOCK_N, kL1Size - kL0Start); kL0SizeAlign=AlignUp(kL0Size,C0)
                aL0 = LoadNzL1ToZzL0A(pL1[kL0Start*mRowsAlign], mRowsAlign, kL0SizeAlign, mRowsAlign)
                bL0 = LoadNzL1ToZnL0B(vL1[kL0Start*C0], kL0SizeAlign, BASE_K, kL1SizeAlign)
                Mmad(cL0, aL0, bL0, cL0, m=mRowsAlign, n=BASE_K, k=kL0SizeAlign,
                     cmatrixInitVal=isFirstK); isFirstK=false
        Fixpipe cL0 → oSlot[mL0Start*dimAlign]  (mSize=mRows, nSize=BASE_K,
                       srcStride=mRowsAlign, dstStride=dimAlign)
    oQueue.ProducerReleaseFix()
```

要点：
- MM2 的右矩阵 V 用基线已有的 `LoadNzL1ToZnL0B`（**不需要转置 helper**）。
- `P·V` 沿 reduce 维（KV 行）累加，`cmatrixInitVal` 仅第一段为 true，后续累加（`Mmad(cL0,...,cL0,...)`）。
- V 每个 reduce 段只搬一次 L1，被该任务该 Q 微块复用。

---

## 6. Vec 侧联动适配（必须改，否则结果错）

分块粒度从 128 变成 `mBaseSize × s2BaseSize` 后，vec 侧的迭代结构、workspace 粒度、softmax 状态索引都要联动改。online-softmax 沿 **KV 外层块（s2OuterBlocks）** 迭代，每个外层块一次性处理 `s2Rows` 列（最多 512）。

### 6.1 workspace slot 粒度放大
所有 per-slot workspace 从 `BLOCK_M × BLOCK_N`（128×128）放大到 `mBaseSize × s2BaseSize`：
- `wsS`（float，S 矩阵）：slot = `mBaseSize × s2BaseSize`，列跨度 `s2BaseSize`。
- `wsP`（fp16，概率）：slot = `mBaseSize × s2BaseSize`。
- `wsO`（float，MM2 输出）：slot = `mBaseSize × dimAlign`。
- `wsMeta`/`wsAccO`：见 6.4。
vec 侧 `sQueue_/pQueue_/oQueue_.Init` 的 slotSize 必须与 cube 侧一致地用 `mBaseSize × s2BaseSize`、`mBaseSize × dimAlign`。

### 6.2 行方向二次切分（M 子块）
一个任务的 `qRows`（最多 512）在两个 AIV subblock 间按行劈分（`SetMSplitInfo`：偶 subblock 取前半、奇 subblock 取后半，按 16 行对齐），每个 subblock 再按 `vec1ChunkRows_` 行分块循环处理 softmax，避免 UB 溢出。
- `vec1ChunkRows_ = VEC_QUEUE_BUF_SIZE / (s2BaseSize × sizeof(float))`，再向上对齐到 8 的倍数（保证 softmax state 写入 32B 对齐）。`VEC_QUEUE_BUF_SIZE` 推荐 32 KB。
  - 本 shape：32768/(512×4)=16 行/块 → 对齐后 16。
- **`s2BaseSize ≤ 1024` 的硬约束就来自这里**：若 s2BaseSize=2048，则 vec1ChunkRows=4 < 8，state 写入地址不再 32B 对齐 → 精度错或对齐异常。

### 6.3 ComputeVec1（scale + mask + online-softmax）
```
ComputeVec1(slot, isFirst, kvRows):     # kvRows = 本 KV 外层块实际行数 s2Rows
    sSlot = sQueue.ConsumerAcquire(); pSlot = pQueue.ProducerAcquire()
    outerCols = s2BaseSize
    for chunkRow in 0 .. vecDealM step vec1ChunkRows_:
        dealRows = min(vec1ChunkRows_, vecDealM - chunkRow)
        sUb = copy S[ sSlot[(vecStartM+chunkRow)*outerCols] ]  (dealRows × outerCols)
        Muls(sUb, smScale)
        # SoftMaxShapeInfo: srcM=dealRows, srcK=outerCols, oriSrcK=kvRows
        #   oriSrcK=kvRows(实际KV列) 让 softmax 只在有效列上归约，自动屏蔽 padding 列，
        #   省掉基线里手写的 -inf mask（基线对 128 列尾块用 maskBuf 填 -inf）。
        SoftmaxFlashV2(sUb, sum=sumCache[slot,base], max=maxCache[slot,base], sUb,
                       exp=expCache[slot,base], inSum/inMax = (isFirst? default : prevSlot),
                       smTiling, srcShape)
        pHalf = Cast(sUb → fp16);  copy pHalf → pSlot[(vecStartM+chunkRow)*outerCols]
    pQueue.ProducerReleaseMte3()
```
关键变化 vs 基线：
- 基线 srcK 固定 128 且手工 `-inf` mask 尾块；本轮 srcK=`s2BaseSize`、`oriSrcK=kvRows`，**靠 softmax 的 oriSrcK 自动处理 KV 尾块**，删掉 maskBuf 逻辑。
- softmax 的 max/sum/exp 状态按 `slot` 环形缓存，`isFirst`（首个 KV 外层块）用 -inf/0 默认值，否则读 `prevSlot` 状态做 online 合并。


### 6.4 ComputeVec2（O 的 online 重缩放 + 归一化 + 写回）
```
ComputeVec2(slot, isFirst, isLast):
    oSlot = oQueue.ConsumerAcquire()
    mChunk = (VEC_QUEUE_BUF_SIZE/dimAlign) 向下取 BRCB(8) 倍, clamp ≤255, ≤vecDealM
    for ci in 0 .. loopCount:
        dealRows, rowOffset = ...
        oNewUb = copy O_tile[ oSlot[rowOffset*dimAlign] ]   (dealRows × dimAlign)
        if not isFirst:                       # 与上一 KV 外层块累计 O 做 online 合并
            oPrevUb = copy wsAccO[prevSlot, rowOffset]       # 上轮累计
            expBrcb = Brcb(expCache[slot, rowOffset])         # 上轮→本轮的 rescale 因子
            RowMuls(oPrevUb, oPrevUb, expBrcb)
            Add(oNewUb, oNewUb, oPrevUb)
        if isLast:                            # 最后一个 KV 外层块：除以 sum 归一化后写 outGm
            sumBrcb = Brcb(sumCache[slot, rowOffset]); RowDivs(oNewUb, sumBrcb)
            FinalizeOutputChunk(oNewUb → outGm)
        else:                                 # 中间块：累计存回 wsAccO[slot]
            copy oNewUb → wsAccO[slot, rowOffset]
```
- `wsAccO`、`wsMeta` 的 slot 也按 `mBaseSize` 放大（`RING_SLOTS × mBaseSize × dimAlign`、`RING_SLOTS × mBaseSize × 3`）。
- exp/sum 状态从 6.3 的 cache 读；`accOffset` 用 `prevSlot * mBaseSize + rowOffset` 寻址（基线是 `* BLOCK_M`）。
- `FinalizeOutputChunk` 的输出地址基于 `curQRowStart_ + startRow`（任务级 Q 行起点），不再是基线的 `curBx_ * BLOCK_M`。

### 6.5 UB 容量校验（192 KB）
单缓冲峰值（推荐取值，本 shape）：
- `inputQue1_` 1×32KB（或 double 时 2×32KB=64KB，本轮单缓冲取 32KB）。
- `outputQue1_` 32KB。
- `tmpBuf_`（softmax work）32KB。
- `maxCache/sumCache/expCache` 各 `RING_SLOTS × 2KB` = 3×2KB×3 = 18KB。
- `softmaxMax/SumDefault` 各 2KB。
- 合计约 32+32+32+18+4 ≈ **118 KB < 192 KB** ✅。
- 若 `s2BaseSize` 偏大导致 input/output queue 元素超 `VEC_QUEUE_BUF_SIZE/4`，必须靠 `vec1ChunkRows_` 行切分把单次处理量压到 ≤ buffer，这是 6.2 行切分的根本目的。

---

## 7. tiling 结构体新增字段（host↔kernel 契约）

在 `FlashAttentionTiling` 中**新增**以下字段（kernel 侧只读）：
- `uint32_t mBaseSize;`
- `uint32_t s2BaseSize;`
- `uint32_t qOuterBlocks;`     // = ceil(qSeqLenAlign / mBaseSize)
- `uint32_t s2OuterBlocks;`    // = ceil(kvSeqLen / s2BaseSize)

保留基线已有的 `seqBlocks/kvLoops/tailValid/...`（可不再用，但不要删，避免破坏结构体布局对齐）。建议把整个结构体字段类型从 `int32_t` 统一为 `uint32_t`，并相应地让 `CopyTiling` 按 `uint32_t` 拷贝（基线是 int32），保持 host/kernel 一致。

### 7.1 host 侧 doOpTiling 计算（新增部分）
```
s2BaseSize    = SelectS2BaseSize(qSeqLen, groupNum)     # 见 1.1
mBaseSize     = SelectMBaseSize(qSeqLen, s2BaseSize)
qOuterBlocks  = ceil(qSeqLenAlign / mBaseSize)
s2OuterBlocks = ceil(kvSeqLen   / s2BaseSize)
totalGSq      = groupNum * qOuterBlocks                  # 替换基线的 groupNum*seqBlocks
totalBNkv     = batch * nkv
usedCoreNum   = min(totalBNkv*totalGSq, MAX_CORES)
FillCoreRangeEnds(totalBNkv, totalGSq, usedCoreNum, tiling)   # 逻辑同基线
```

### 7.2 workspace 放大（host 侧 perCoreBytes）
所有 per-slot 尺寸把 `BLOCK_M/BLOCK_N` 换成 `mBaseSize/s2BaseSize`：
```
wsSSize    = RING_SLOTS * mBaseSize * s2BaseSize * sizeof(float)
wsPSize    = RING_SLOTS * mBaseSize * s2BaseSize * qElementSize
wsOSize    = RING_SLOTS * mBaseSize * dimAlign  * sizeof(float)
wsMetaSize = RING_SLOTS * mBaseSize * 3         * sizeof(float)
wsAccOSize = RING_SLOTS * mBaseSize * dimAlign  * sizeof(float)
perCoreBytes = wsS+wsP+wsO+wsMeta+wsAccO ;  totalWsBytes = perCoreBytes * usedCoreNum
```
本 shape（mBaseSize=512, s2BaseSize=512, dimAlign=128, RING_SLOTS=3, fp16）：
- wsS=3×512×512×4=3MB，wsP=3×512×512×2=1.5MB，wsO=wsAccO=3×512×128×4=768KB，wsMeta≈18KB。
- perCore ≈ 6 MB；×usedCoreNum(≤20) ≈ 120 MB —— GM workspace，远小于 device HBM，OK。


---

## 8. 数据布局速查（NZ / Mmad 视角）

- GM 中 Q/K/V/O 均为 ND（行优先），形状 `[batch, heads, seqLen, dim]`。
- `LoadNdGmToNzL1` 把 `m×n` 的 ND 块转成 NZ：C0=16 的小列块沿行堆叠，`dstNzC0Stride` = 行容量（决定每个 C0 块在 L1 的行跨度）。尾块行数 < 容量时，传 `dstNzC0Stride = AlignUp(actualRows, C0)`。
- Mmad 约定：左矩阵 L0A 为 Zz、右矩阵 L0B 为 Zn、输出 L0C 为 Nz；`m/n/k` 必须按 C0/16 对齐传入（用 `AlignUp(x, C0)`）。
- MM1：A=Q（m=Q行, k=dim），B=Kᵀ（k=dim, n=KV行），C=S（m×n）。
- MM2：A=P（m=Q行, k=KV行），B=V（k=KV行, n=dim），C=O（m×n）。

---

## 9. 正确性检查清单（实现者自检）

1. `mBaseSize % BLOCK_M == 0`、`s2BaseSize % BLOCK_N == 0`、`s2BaseSize ≤ 1024`。
2. cube 与 vec 两侧的 `sQueue_/pQueue_/oQueue_.Init` slotSize 必须用**同一套** `mBaseSize×s2BaseSize` / `mBaseSize×dimAlign`，否则 AIC/AIV 读写错位。
3. Q 尾块（`qRows < mBaseSize`）、KV 尾块（`s2Rows < s2BaseSize`）、dim 尾块（`dim % BASE_K`，本 shape 为 0）都要用 `min/AlignUp` 正确收口。
4. softmax `oriSrcK = kvRows`（实际有效 KV 列）务必正确传入，替代基线手写 `-inf` mask；否则尾块归约会把 padding 算进去。
5. online-softmax 状态 cache 的 `slot`/`prevSlot` 环形索引、`isFirst/isLast` 边界要和 KV 外层循环对齐。
6. 输出写回地址基于任务级 `qRowStart`，并用 `qSeqLen` 钳位有效行（避免写越界到 padding 区）。
7. L1 峰值 ≤ 512KB、UB 峰值 ≤ 192KB（见 3.4 / 6.5）。

---

## 10. 验证方式
- 编译 + 精度：`scripts/evaluate_ascendc.sh current_task basic`（先过基础用例）。
- 基准 shape：`4,32,4,1024,1024,128,float16`。
- 精度判据：参考前序实验，REL ~1e-3、mismatch 0% 即与基线一致。

---

## 11. 待验证假设（收益预期与风险）

### 11.1 预期收益
- **直接效果（确定）**：K、V 的 GM→L1 重复搬运次数从 `qOuterBlocks`（基线等效 8 次）降到每个 KV 外层块 1 次。本 shape 下 K/V 搬运量降到约 **1/4**（qOuterBlocks 由 8 降到 2，因 mBaseSize=512 把 4 个 Q 微块合到一个任务）。
- **对端到端时延的预期**：**可能接近 0**。本工作区已有前序实验（`artifacts/two_level_tiling_verify.md`）实测：在 66a35f8 上单独引入「两级分块 + L1 复用」、**不带流水**时，端到端 2406us vs 基线 2391us（略慢 0.6%），加速比仍 ~1.0x。

### 11.2 根因分析（为何独立收益低）
- 该 shape 下 GM 搬运**不是唯一瓶颈**。基线/本轮都用同核硬同步（`SetWaitFlag<HardEvent>` + CrossCore flag），**搬运与计算完全串行**：省下的搬运时间被计算阶段的等待吃掉。
- 真正带来 4x 提速（605us）的是后续轮次的 **double buffer + TQue 多缓冲流水**（搬运/计算重叠），而非两级分块的 L1 复用本身。
- **两级分块的真正价值**：为后续流水提供**足够大的重叠粒度**（大块搬运 + 多微块计算可被流水掩盖）。它是流水优化的**结构前提**，单独存在收益有限，但缺了它流水无从展开。

### 11.3 主要风险点
1. **softmax 大列归约精度**：srcK 从 128 增大到 512，`SoftMaxFlashV2TilingFunc` 的临时 buffer 与 `vec1ChunkRows_` 对齐（8 的倍数 / 32B）必须正确，否则尾块/对齐错误导致精度劣化或 alignment 异常。
2. **UB 溢出**：`s2BaseSize` 越大，单行 S 越长，`vec1ChunkRows_` 越小；若实现时忘了按 `vec1ChunkRows_` 行切分而整块进 UB，会超 192KB。务必落实 6.2 的行切分。
3. **MM1 K 转置加载**：基线无 `WithTranspose` helper（见 4.1）。若实现者新写 helper，要核对 C0 分块循环的 src/dst 偏移；优先复用基线 (B) 方案降低风险。
4. **tiling 结构体布局一致性**：新增字段后 host 写入顺序与 kernel `CopyTiling` 读取顺序必须逐字段对齐；建议字段类型统一 uint32 并同步改 `CopyTiling`。
5. **slot 粒度放大后的 workspace 寻址**：`* BLOCK_M` 全部要改成 `* mBaseSize`（accO/meta/O 偏移），漏改会读写错位、结果错乱。

